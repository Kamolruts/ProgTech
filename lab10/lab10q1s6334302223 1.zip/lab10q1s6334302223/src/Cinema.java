
/**
 *
 * @author 6334302223
 */
public class Cinema {

    private String name;     
    private int ticketPrice; 

    public Cinema(String name, int ticketPrice) {
        this.name = name;
        this.ticketPrice = ticketPrice;
    }

    public String getName() {
        return name;
    }
    
    public int getTicketPrice() {
        return ticketPrice;
    }   
}
