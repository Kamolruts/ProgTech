import java.util.Scanner;
/**
 *
 * @author 6334302223 Kamolrut Sonti
 */
public class Q1 {
    public static void main(String[] args) {
        Scanner input1 = new Scanner(System.in);
        
        System.out.println("Press 1 to sum three integers.");
        System.out.println("Press 2 to find roots of a quadratic equation.");
        System.out.println("Press 3 to find the area of a rectangle.");
        System.out.println("Press 4 to print A's.");
        int Press = input1.nextInt();
        
        int Case = Press;
        String ans ="";
        switch (Case)
        {
            case 1 : 
                Scanner input2 = new Scanner(System.in);
                System.out.println("Enter 3 integers:");
                String data2 = input2.nextLine();
                String[] part2 = data2.split(" ");
                String Si1 = part2[0];
                String Si2 = part2[1];
                String Si3 = part2[2];
                int i1 = Integer.parseInt(Si1);
                int i2 = Integer.parseInt(Si2);
                int i3 = Integer.parseInt(Si3);
                int isum = i1 + i2 + i3;
                String sum = "Sum: " + isum;
                ans = sum;
                input2.close();
            break;
            case 2 : 
                Scanner input3 = new Scanner(System.in);
                System.out.println("Enter a, b, c for ax^2+bx+c=0 :");
                String data3 = input3.nextLine();
                String[] part3 = data3.split(" ");
                String Sa = part3[0];
                String Sb = part3[1];
                String Sc = part3[2];
                Double a = Double.parseDouble(Sa);
                Double b = Double.parseDouble(Sb);
                Double c = Double.parseDouble(Sc);
                Double inroot = Math.sqrt(Math.pow(b, 2)-4*a*c);
                if (inroot>=0 && a!=0) {
                    Double x1 = (-b + Math.sqrt(Math.pow(b, 2)-4*a*c))/(2*a);
                    Double x2 = (-b - Math.sqrt(Math.pow(b, 2)-4*a*c))/(2*a);
                    String tworoots = "Two roots: " + x1 + ", " + x2;
                    ans = tworoots;
                } else {
                    String NoSol = "No Solution";
                    ans = NoSol;
                }
                    input3.close();
            break;
            case 3 :
                Scanner input4 = new Scanner(System.in);
                System.out.println("Enter the length of 2 sides of the rectangle:");
                String data4 = input4.nextLine();
                String[] part4 = data4.split(" ");
                String Sl1 = part4[0];
                String Sl2 = part4[1];
                Double l1 = Double.parseDouble(Sl1);
                Double l2 = Double.parseDouble(Sl2);
                Double area = l1*l2;
                String Area = "Area: " + area;
                ans = Area;
                input4.close();
            break;
            case 4 :
                Scanner input5 = new Scanner(System.in);
                System.out.println("How many A's?");
                int num = input5.nextInt();
                String str = "A";
                String repeat = str.repeat(num);
                ans = repeat;
                input5.close();
            break;
            default : ans ="";
            System.out.println("Invalid choice");
            break;
        }
        input1.close();

        
            System.out.println(ans);
        
        
    }
    
}
