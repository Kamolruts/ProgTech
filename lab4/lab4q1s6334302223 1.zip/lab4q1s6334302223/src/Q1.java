import java.util.Scanner;
import java.lang.Math;
/**
 *
 * @author 6334302223 Kamolrut Sonti
 */
public class Q1 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.print("First point : ");
        double x1 = input.nextDouble();
        double y1 = input.nextDouble();
        
        System.out.print("Second point : ");
        double x2 = input.nextDouble();
        double y2 = input.nextDouble();
        
        System.out.print("Third point : ");
        double x3 = input.nextDouble();
        double y3 = input.nextDouble();
        
        System.out.print("Fourth point : ");
        double x4 = input.nextDouble();
        double y4 = input.nextDouble();
        
        double ctx = (x1+x2+x3+x4)/(4);
        double cty = (y1+y2+y3+y4)/(4);  
        System.out.println("The centroid is " + "( " + ctx + ", " + cty + " ).");
        
        
        double dp1 = Math.sqrt(Math.pow((x1-ctx),2) + Math.pow((y1-cty),2));
        double dp2 = Math.sqrt(Math.pow((x2-ctx),2) + Math.pow((y2-cty),2));
        double dp3 = Math.sqrt(Math.pow((x3-ctx),2) + Math.pow((y3-cty),2));
        double dp4 = Math.sqrt(Math.pow((x4-ctx),2) + Math.pow((y4-cty),2));
        double sdp = dp1 + dp2 + dp3 + dp4;
        
        double min1 = Math.min(dp1,dp2);
        double min2 = Math.min(min1,dp3);
        double min = Math.min(min2,dp4);

        
        double max1 = Math.max(dp1,dp2);
        double max2 = Math.max(max1,dp3);
        double max = Math.max(max2,dp4);

        
        System.out.println("Sum of distance is " + sdp + ".");
        
        
        
        System.out.println("Shortest distance is " + min + ".");
        System.out.println("Longest distance is " + max + ".");
        
        
        
    }
    
}
