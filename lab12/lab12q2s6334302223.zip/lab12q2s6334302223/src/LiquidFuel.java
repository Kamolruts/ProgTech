
/**
 *
 * @author 6334302223
 */
public interface LiquidFuel {

    double getRange();
    int getEmissionTier();
    
}
