
/**
 *
 * @author 6334302223
 */
public interface Electric {
    
    double HIGH_VOLTAGE = 600;
    double LOW_VOLTAGE = 480;
    
    double getVoltage();
    
}
