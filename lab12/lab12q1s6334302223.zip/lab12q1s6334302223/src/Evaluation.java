
/**
 *
 * @author 6334302223
 */
public interface Evaluation {
    
    double evaluate();
    char grade(double sumScore);
    
}
